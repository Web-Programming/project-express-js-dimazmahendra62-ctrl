// var express = require('express');
// var router = express.Router();
// var product = require("../../data")

// // Import data produk dari JSON
// var products = require('../data/product.json');

// /* GET home page */
// router.get('/', function(req, res, next) {
//   res.render('index', { 
//     title: 'Toko Online',
//     products: products
//   });
// });

// module.exports = router;

var express = require('express');
var router = express.Router();

// Route detail review produk
router.get('/:productId/review/:reviewId', function(req, res, next) {
  const productId = req.params.productId;
  const reviewId = req.params.reviewId;

  // Kirim parameter ke view
  res.render('review-detail', {
    title: 'Ulasan ${reviewedId} untuk Produk ${productId}',
    productId: productId,
    reviewId: reviewId
  });
});

module.exports = router;